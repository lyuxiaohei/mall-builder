# HTML 原型预览

本文件夹包含可直接在浏览器中预览的 HTML 原型文件。

## 文件说明

| 文件 | 说明 |
|------|------|
| `index.html` | 运营工作台主入口页面，包含模板列表、商城列表等功能 |
| `editor.html` | 模板编辑器页面，用于搭建和编辑商城页面模板 |

## 预览方式

### 方式一：直接双击打开
直接双击 HTML 文件，使用浏览器打开即可预览。

### 方式二：使用本地服务器（推荐）
使用本地服务器可以避免部分跨域问题：

```bash
# 使用 Python 简易服务器（在项目根目录运行）
python -m http.server 8080

# 或使用 Node.js 的 http-server
npx http-server -p 8080
```

然后在浏览器访问：
- 主入口页面：http://localhost:8080/preview/index.html
- 编辑器页面：http://localhost:8080/preview/editor.html

### 方式三：VS Code Live Server
1. 安装 VS Code 的 Live Server 扩展
2. 右键点击 HTML 文件，选择 "Open with Live Server"

## 目录结构

```
mall-builder-prototype/
├── preview/              # HTML 原型预览文件夹
│   ├── index.html        # 主入口页面
│   └── editor.html       # 编辑器页面
├── assets/               # 静态资源（图片等）
├── styles.css            # 样式文件
├── app.js                # 主入口页面逻辑
├── data.js               # 数据文件
└── docs/                 # 文档
```

## 注意事项

1. 这些 HTML 文件为原型演示用途，可直接在浏览器中查看效果
2. 编辑器页面 (editor.html) 是一个大型单文件应用，包含完整的组件库和配置功能
3. 如需修改样式，请编辑根目录下的 `styles.css` 文件
4. 如需修改主入口页面逻辑，请编辑根目录下的 `app.js` 文件